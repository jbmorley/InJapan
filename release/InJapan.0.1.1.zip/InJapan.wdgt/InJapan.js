// The date the timer expires.
Expires = new Date(2005, 7, 13, 13, 00, 00);

// Start things happening.
Id = window.setTimeout("loadPreferences(); displayTime();", 1000);

function loadPreferences() {
    // Get the date.
    var now = new Date();

    // Add the offset to the date.
    now.setTime(now.getTime() + 3600000);

    // Get the elements.
    var daySelect = document.getElementById("day");
    var monthSelect = document.getElementById("month");
    var yearSelect = document.getElementById("year");
    var hourSelect = document.getElementById("hour");
    var minuteSelect = document.getElementById("minute");

    // Check to see if any settings have been stored
    // for this instance of the widget.
    var day = widget.preferenceForKey(createKey("Day"));
    var month = widget.preferenceForKey(createKey("Month"));
    var year = widget.preferenceForKey(createKey("Year"));
    var hour = widget.preferenceForKey(createKey("Hour"));
    var minute = widget.preferenceForKey(createKey("Minute"));

    // Check that they are all defined.
    // If they are not defined, then set the timer for an hour in the
    // future.
    // As I do not know of a 'defined' funciton in javascript, this
    // will have to suffice as a reasonable check.
    if (!day && !month && !year && !hour && !minute) {

        // Re-calculate the values.
        day = now.getDate();
        month = now.getMonth()
        year = now.getYear();
        hour = now.getHours();
        minute = now.getMinutes();

        // Save these as the settings for this widget.
        widget.setPreferenceForKey(day, createKey("Day"));
        widget.setPreferenceForKey(month, createKey("Month"));
        widget.setPreferenceForKey(year, createKey("Year"));
        widget.setPreferenceForKey(hour, createKey("Hour"));
        widget.setPreferenceForKey(minute, createKey("Minute"));        

    }

    // Set the elements.
    daySelect.options[day-1].selected = true;
    monthSelect.options[month].selected = true;
    yearSelect.options[year-105].selected = true;
    hourSelect.options[hour].selected = true;
    minuteSelect.options[minute].selected = true;

    // Set the time.
    Expires = new Date(year+1900, month, day, hour, minute, 00);

}

function savePreferences() {
    // Get the elements.
    var daySelect = document.getElementById("day");
    var monthSelect = document.getElementById("month");
    var yearSelect = document.getElementById("year");
    var hourSelect = document.getElementById("hour");
    var minuteSelect = document.getElementById("minute");

    // Get the time.
    var day = daySelect.selectedIndex + 1;
    var month = monthSelect.selectedIndex;
    var year = yearSelect.selectedIndex + 105;
    var hour = hourSelect.selectedIndex;
    var minute = minuteSelect.selectedIndex;

    // Save the setting.
    widget.setPreferenceForKey(day, createKey("Day"));
    widget.setPreferenceForKey(month, createKey("Month"));
    widget.setPreferenceForKey(year, createKey("Year"));
    widget.setPreferenceForKey(hour, createKey("Hour"));
    widget.setPreferenceForKey(minute, createKey("Minute"));

    // Set the new time.
    Expires = new Date(year+1900, month, day, hour, minute, 00);

    // Force a re-initialization just incase we have already
    // stopped the timer.
    hideSplash();
    displayTime();
}

// Inspired by Apple's World Clock widget.
function createKey(key) {
    return widget.identifier + "-" + key;
}

function displayTime() {
    // Get the date.
    var Now = new Date();

    // Millseconds remaining.
    Remaining = Expires - Now;
    AlwaysRemaining = Remaining;

    // Check that we haven't reached the end.
    if (Remaining <= 0) {
	Remaining = 0;
    }

    // Millsecond Conversions.
    // seconds = 1,000
    // minutes = 60,000
    // hours = 3,600,000
    // days = 86,400,000

    Days = parseInt(Remaining/86400000);
    Remaining = Remaining % 86400000;

    Hours = parseInt(Remaining/3600000);
    Hours = ((Hours < 10) ? "0" : "") + Hours;
    Remaining = Remaining % 3600000;

    Minutes = parseInt(Remaining/60000);
    Minutes = ((Minutes < 10) ? "0" : "") + Minutes;
    Remaining = Remaining % 60000;

    Seconds = parseInt(Remaining/1000);
    Seconds = ((Seconds < 10) ? "0" : "") + Seconds;
    Remaining = Remaining % 1000;

    Milliseconds = Remaining;
    if (Milliseconds < 10) {
        Milliseconds = "00" + Milliseconds;
    } else if (Milliseconds < 100) {
        Milliseconds = "0" + Milliseconds;
    }

    // If we are still counting...
    if (AlwaysRemaining > 0) {
        // Display the date.
        timediv = document.getElementById("time");
        timediv.innerHTML
            = Days+" days "+Hours+":"+Minutes+":"+Seconds+" ."+Milliseconds;

        // Wait, then run again.
        Id = window.setTimeout("displayTime();", 75);
    } else {
        timediv = document.getElementById("time");
        timediv.innerHTML = "";

        showSplash();
    }
}

function showSplash() {
    document.getElementById('overlay').style.display = 'block';
}

function hideSplash() {
    document.getElementById('overlay').style.display = 'none';
}

/*
setup() is run when the body loads.  It checks to see if there is a preference
for this widget and if so, applies the preference to the widget.
*/

function setup() {
    // Check we are running in Dashboard.
    if (window.widget) {}

    createGenericButton(document.getElementById('done'), 'Back', hidePrefs);
}

// Show the preferences.
function showPrefs() {
    var front = document.getElementById("front");
    var back = document.getElementById("back");
	
    // Freezes the widget so that you can change it without the user noticing
    if (window.widget)
        widget.prepareForTransition("ToBack");
	
    front.style.display="none";	// hide the front
    back.style.display="block";	// show the back

    // Flip the widget over.
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);

    // Clean up the front side - hide the circle behind the info button
    document.getElementById('fliprollie').style.display = 'none';
}

// Hide the preferences.
function hidePrefs() {

    // First, change the settings to reflect those on the
    // preferences screen.
    savePreferences();

    var front = document.getElementById("front");
    var back = document.getElementById("back");

    // Freezes the widget and prepares it for the flip back to the front
    if (window.widget)
        widget.prepareForTransition("ToFront");
	
    back.style.display="none"; // hide the back
    front.style.display="block"; // show the front

    // Flip the widget back to the front
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}


// PREFERENCE BUTTON ANIMATION (- the pref flipper fade in/out)

// A flag used to signify if the flipper is currently shown or not.
var flipShown = false;

// A structure that holds information that is needed for the animation to run.
var animation = {
                 duration:0,
                 starttime:0,
                 to:1.0,
                 now:0.0,
                 from:0.0,
                 firstElement:null,
                 timer:null
                };

/*
mousemove() is the event handle assigned to the onmousemove property on
the front div of the widget.
It is triggered whenever a mouse is moved within the bounds of your widget.
It prepares the preference flipper fade and then calls animate() to performs
the animation.
*/

function mousemove (event) {
    // if the preferences flipper is not already showing...
    if (!flipShown) {
        // reset the animation timer value, in case a value was left behind
        if (animation.timer != null) {
	    clearInterval(animation.timer);
	    animation.timer = null;
        }

        // Set it back one frame
        var starttime = (new Date).getTime() - 13;
		
	animation.duration = 500; // animation time, in ms
        animation.starttime = starttime; // specify the start time
        
        // specify the element to fade
        animation.firstElement = document.getElementById ('flip');

        // set the animation function
        animation.timer = setInterval ("animate();", 13);
	
        animation.from = animation.now;	// beginning opacity (not ness. 0)
	animation.to = 1.0; // final opacity
	
        animate(); // begin animation
        flipShown = true; // mark the flipper as animated
    }
}


/*
mouseexit() is the opposite of mousemove() in that it preps the preferences
flipper to disappear.  It adds the appropriate values to the animation data
structure and sets the animation in motion.
*/

function mouseexit (event) {
    if (flipShown) {
        // fade in the flip widget
	if (animation.timer != null) {
            clearInterval (animation.timer);
            animation.timer  = null;
	}
		
        var starttime = (new Date).getTime() - 13;
		
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('flip');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 0.0;
        animate();
        flipShown = false;
    }
}


/*
animate() performs the fade animation for the preferences flipper. It uses
the opacity CSS property to simulate a fade.
*/

function animate() {
    var T;
    var ease;
    var time = (new Date).getTime();
		
    T = limit_3(time-animation.starttime, 0, animation.duration);
	
    if (T >= animation.duration) {
        clearInterval (animation.timer);
        animation.timer = null;
        animation.now = animation.to;
    } else {
        ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
	animation.now = computeNextFloat (animation.from, animation.to, ease);
    }
    
    animation.firstElement.style.opacity = animation.now;
}


// these functions are utilities used by animate()
function limit_3 (a, b, c) {
    return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease) {
    return from + (to - from) * ease;
}

// these functions are called when the info button itself receives onmouseover and onmouseout events

function enterflip(event) {
    document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(event) {
    document.getElementById('fliprollie').style.display = 'none';
}
